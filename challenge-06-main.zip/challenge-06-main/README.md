# Panduan

after clone bisa jalanin perintah ini ya

``` yarn Install ```

habis itu bisa start aja

``` yarn start ```